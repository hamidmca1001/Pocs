using FlightTest;
using System;
using Xunit;

namespace FlightUnitTest
{
    public class FlightBuilderTest
    {
        [Fact]
        public void ShouldReturnAllFlights()
        {
            FlightBuilder flightBuilder = new FlightBuilder();
            var response=  flightBuilder.GetFlights();
            Assert.True(response.Count > 0);
        }
    }
}
