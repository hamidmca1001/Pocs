﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightTest
{
    /// <summary>
    /// Segment
    /// </summary>
    public class Segment
    {
        /// <summary>
        /// DepartureDate
        /// </summary>
        public DateTime DepartureDate { get; set; }

        /// <summary>
        /// ArrivalDate
        /// </summary>
        public DateTime ArrivalDate { get; set; }
    }
}
