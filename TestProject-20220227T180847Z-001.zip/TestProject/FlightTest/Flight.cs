﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlightTest
{
    public class FlightBase
    {
        
    }
    /// <summary>
    /// Fligth class
    /// </summary>
    public class Flight
    {
        /// <summary>
        /// Segments
        /// </summary>
        public IList<Segment> Segments { get; set; }

        
    }
}
