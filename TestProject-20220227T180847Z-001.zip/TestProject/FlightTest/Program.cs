﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FlightTest
{
    class Program
    {
        static void Main(string[] args)
        {
            FlightBuilder ob = new FlightBuilder();
            var response = ob.GetFlights();
            DateTime dateTime = DateTime.UtcNow;

            GetDepartureList(dateTime, response);

            //This is for point 2
             InvalidScedhuleFlight(response);

            int hours = 2;
            GetGoundedFlight(response, hours);

            Console.Read();
        }

        private static void InvalidScedhuleFlight(IList<Flight> response)
        {
            var invalidSechduleList = response.SelectMany(x => x.Segments.Where(y => y.DepartureDate > y.ArrivalDate).ToList());

            foreach (var depart in invalidSechduleList)
            {
                Console.WriteLine($"Deparut time :{ depart.DepartureDate} : Arrival time  { depart.ArrivalDate}");
            }
        }

        private static void GetGoundedFlight(IList<Flight> response, int hour)
        {
            //This is for point 3
            var groundFightList = response.SelectMany(x => x.Segments.Where(y => (y.ArrivalDate.Hour - y.DepartureDate.Hour) > hour).ToList());

            foreach (var depart in groundFightList)
            {
                Console.WriteLine($"Deparut time :{ depart.DepartureDate} : Arrival time  { depart.ArrivalDate}");
            }
        }

        private static void GetDepartureList(DateTime dateTime, IList<Flight> response)
        {
            // this for point 1
            var deaprtureList = response.SelectMany(x => x.Segments.Where(y => y.DepartureDate <= dateTime).ToList());

            foreach (var depart in deaprtureList)
            {
                Console.WriteLine($"Deparut time :{ depart.DepartureDate} : Arrival time  { depart.ArrivalDate}");
            }
        }
    }
}

